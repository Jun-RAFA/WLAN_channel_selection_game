% custom_distance_matrix.m
function [dist_matrix, points] = make_distance_matrix(x_limit, y_limit, N, r, option, varargin)

    persistent stored_points;

    if option == 1
        stored_points = generate_points(x_limit, y_limit, N, r);
    elseif option == 2
        if isempty(varargin)
            error('Please provide M for option 2');
        else
            M = varargin{1};
            stored_points = [stored_points; generate_points(x_limit, y_limit, M, r)];
        end
    elseif option == 3
        if isempty(stored_points)
            error('No points generated. Please use option 1 or 2 first.');
        end
    else
        error('Invalid option. Choose 1, 2, or 3.');
    end

    points = stored_points;
    dist_matrix = pdist2(points, points);
end

