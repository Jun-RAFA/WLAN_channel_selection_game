
clear all

% N: the number of APs
% K: the number of channels
% max_avg: the number of iterations for the program to take an average.
N = 24;
K = 3;
max_avg = 40;

% r: the minimum distance between two APs.
% length_x: the length of x for a rectangle
% length_y: the length of x for a rectangle
% P_t: transmit power of APs.
r = 10;
P_t = 21;
length_x = 200;
length_y = 200;
ll = 0;
for N = 24:2:24
    N
    ll = ll + 1;
    for avg_it = 1: max_avg   

        %%%%%%%%%%%%%% Construct a topology %%%%%%%%%%%%%%%%%%
        [Qt,R,option_points] = build_topology(length_x, length_y, N, K, r);
        
        % num_NE: the number of pure-strategy Nash equilibrium (PSNE)
        % max_iter: the number of trials that we try to find a PSNE
        % If max_iter is large enough, we can find more than one PSNE

        max_iter = 1;
        num_NE = 1;
        
        for iter = 1: max_iter

            %%% intially, all APs randomly choose a channel among K
            init_ch =  zeros(K,N);
            for i = 1: N
                AP(i).channel = unidrnd(K);
                init_C(i) = AP(i).channel;
                init_ch(AP(i).channel,i) = 1;
            end
            u =  [];
            for k = 1:K
                u = [u init_ch(k,:)];
            end
            init_CCI(iter) = 0.5*u*Qt*u';
            %%% End of initialization

            % r is the number of rounds to reach a PSNE
            % It is set to a sufficiently large number
            not_converge = 0;
            for r = 1:1000
                % AP(i).channel takes an integer from 1 to K. 
                % We convert it into a binary value 
                ch = zeros(K,N);
                for i = 1:N
                    ch(AP(i).channel,i) = 1;
                end
                % generate a random sequence of N APs to choose a channel
                rnd_seq = randperm(N);
                for l = 1:N
                    % n: AP's index, is going to choose a channel
                    n = rnd_seq(l);
                    for i = 1:K
                        val(i) = R(n,:)*ch(i,:)';
                    end
                    indifferent = find(val(1)~=val);
                    if isempty(indifferent) == 1
                        break
                    else
                        % Sort each channel index in the ascending order of
                        % it CCI. If (at least one) AP n changes its channel, this is not
                        % a PSNE yet.
                        [value,index] = min(val);
                        if AP(n).channel ~= index
                            not_converge = 1;
                        end
                        % Reset the previous channel allocation
                        ch(AP(n).channel,n) = 0;
                        % Update the current channel allocation
                        AP(n).channel = index;
                        ch(AP(n).channel,n) = 1;
                        % To present the result as a vector
                        %C(n) = AP(n).channel;
                    end
                end                
                if not_converge == 0
                    % if a PSNE is found, we escape this loop
                    avg_time(iter) = r;
                    break
                else
                    not_converge = 0;
                end
            end

            x =  [];

            for k = 1:K
                x = [x ch(k,:)];
            end

            %%% In this routine y stores all the different PSNEs by
            %%% comparing a PSNE newly found with the previous PSNEs
            if num_NE == 1
                y(num_NE,:) = x;
                CCI(num_NE) = 0.5*x*Qt*x';
                init_CCI(num_NE) = 0.5*u*Qt*u';
                num_NE = num_NE + 1;
            else
                skip = 0;
                z = 0;
                for k = 1:num_NE-1
                    t = sum(xor(x,y(k,:)));
                    if t == 0
                        skip = 1;
                        break
                    end
                    z  = z + t;
                end

                if skip ~= 1 && z > 0
                    y(num_NE,:) = x;
                    CCI(num_NE) = 0.5*x*Qt*x';
                    init_CCI(num_NE) = 0.5*u*Qt*u';
                    num_NE = num_NE + 1;
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        conv(avg_it) = mean(avg_time);
        mCCI(avg_it) = 10*log10(mean(CCI));
        %mean(conv)
        bCCI(avg_it) = 10*log10(min(CCI));
        %mean(bCCI)
        wCCI(avg_it) = 10*log10(max(CCI));
       
        %mrCCI(avg_it) = 10*log10(mean(init_CCI));        
        %brCCI(avg_it) = min(init_CCI);        
        %wrCCI(avg_it) = max(init_CCI);
        y=[];
    end
    mx_CCI(ll) = mean(bCCI)
    avg_CCI(ll) = mean(mCCI)
    mn_CCI(ll) = mean(wCCI)

    %rmx_CCI(ll) = mean(brCCI)
    %ravg_CCI(ll) = mean(mrCCI)
    %rmn_CCI(ll) = mean(wrCCI)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define marker shapes
markerShapes = {'o', '+', '*', 's', 'd', '^', 'v', '>', '<', 'p', 'h','.', 'x',};

% Define colors (12 distinct colors)
colors = [
    0, 0, 1;        % Blue
    0, 0.5, 0;      % Dark Green
    1, 0, 0;        % Red
    0, 0.75, 0.75;  % Cyan
    0.75, 0, 0.75;  % Magenta
    0.75, 0.75, 0;  % Yellow
    0.25, 0.25, 0.25;% Grey
    0.5, 0.5, 0.5;  % Dark Grey
    1, 0.5, 0;      % Orange
    0.5, 0, 1;      % Purple
    0, 1, 1;        % Light Cyan
    1, 0, 1;        % Pink
];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sx = option_points(:,1);
sy = option_points(:,2);

figure
hold on;
for i = 1:N
    m = AP(i).channel-1;
    marker = markerShapes{mod(m, numel(markerShapes)) + 1};
    color = colors(mod(m, size(colors, 1)) + 1, :);
    plot(sx(i), sy(i), marker, 'MarkerEdgeColor', color, 'MarkerSize', 10, 'LineWidth', 1.5);
end
hold off;

% Set axis labels and title
xlabel('X-axis');
ylabel('Y-axis');
title('N APs with Different Colors and Marker Shapes');

% Set axis limits
axis([0 length_x 0 length_y]);







