function [points] = generate_points(x_limit, y_limit, num_points, min_dist)
    points = zeros(num_points, 2);
    counter = 1;

    while counter <= num_points
        candidate = [x_limit * rand(), y_limit * rand()];

        if counter == 1
            points(counter, :) = candidate;
            counter = counter + 1;
        else
            distances = pdist2(candidate, points(1:counter-1, :));
            if all(distances >= min_dist)
                points(counter, :) = candidate;
                counter = counter + 1;
            end
        end
    end
end