
function [Qt,R,option_points] = build_topology(length_x, length_y, N, K, r)

[D, option_points] = make_distance_matrix(length_x, length_y, N, r, 1);
R = zeros(size(D));
for i = 1:N
    for j = 1:N
        %Pt = 10^(P_t/10); % milli-watt
        if j~=i
            %    if j == 2 | 4  | 13 | 12%| 24
            %        P_t  = 27;
            %    else
            P_t = 21;
            %    end
            R(i,j) = 10^(street_canyon_pathloss(P_t, D(i,j), 6e9, 10, unifrnd(5,10))/10);
        end
    end
end

Qt = zeros(N*K,N*K);
for i = 1:K
    Qt((i-1)*N+1:(i-1)*N+N,(i-1)*N+1:(i-1)*N+N) = R;
end
