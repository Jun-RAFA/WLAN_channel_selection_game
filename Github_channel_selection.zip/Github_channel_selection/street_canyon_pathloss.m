function received_power = street_canyon_pathloss(tx_power, d, f, h_BS, h_UT)
    % Parameters
    f = f / 1e9; % Convert frequency to GHz

    % LOS probability calculation
    p_LOS = min(18 / d, 1) * (1 - exp(-d / 63)) + exp(-d / 63);

    % LOS path loss
    PL_LOS = 32.4 + 21 * log10(d) + 20 * log10(f);

    % NLOS path loss
    PL_NLOS = 22.4 + 35.3 * log10(d) + 21.3 * log10(f);

    % Calculate total path loss
    PL = p_LOS * PL_LOS + (1 - p_LOS) * PL_NLOS;

    % Calculate received power
    received_power = tx_power - PL;
end
